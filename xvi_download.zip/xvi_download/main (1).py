# Site https://xvideosporno.blog.br/videos/xxx/
from requests import get, head
from bs4 import BeautifulSoup as sp
from json import dumps, loads
from tqdm import tqdm
from os import mkdir
from os.path import isfile, isdir


class Download_xvideos:
	def __init__(self, link):
		self.url = link
		self.filename = None
		self.download_xvideo()

	def get_url_link(self):
		response = get(url=self.url)
		soup = sp(response.text, 'html.parser')
		scripts = soup.find('script', attrs={'type': 'application/ld+json'})
		for script in scripts:
			response_json = loads(script)
			self.filename = response_json['name']
		return response_json['embedUrl']

	def get_link_video(self):
		url = self.get_url_link()
		response = get(url=url)
		soup = sp(response.text, 'html.parser')
		video = soup.find('video', id="video_player")
		link_video = video.find('source').get('src')
		return link_video

	def download_xvideo(self):
		chunk_size = 256*8
		try:
			file_path = mkdir('.Xvideos')
		except:
			pass
		download_file = r'.Xvideos/'
		url = self.get_link_video()
		print('-------------Resolucão----------------')
		print('[0]- 360p\n[1]- 480p\n[2]- 720p\n[3]- 1080p')
		resoluction = input('Sua opção: ')
		if resoluction == '0':
			resoluction = '360'
		elif resoluction == '1':
			resoluction = '480'
		elif resoluction == '2':
			resoluction = '720'
		elif resoluction == '3':
			resoluction = '1080'
		else:
			print('Opção inválida')
		file = head(url=url)
		file_size = int(file.headers.get('content-length', 0))
		resume_byte_pos = False
		if isfile(download_file+self.filename+'.mp4'):
			with open(download_file+self.filename+'.mp4', 'rb') as file:
				resume_byte_pos = len(file.read())
				if file_size == resume_byte_pos:
					return
		resume_header = ({'Range': f'bytes={resume_byte_pos}'} if resume_byte_pos else None)
		url = url.replace('360', resoluction)
		response = get(url=url, stream=True, headers=resume_header)
		mode = 'ab' if resume_byte_pos else 'wb'							  
		with open(download_file+self.filename+'.mp4', mode) as file:
			for chunk in tqdm(response.iter_content(chunk_size=chunk_size)):
				try:
					file.write(chunk)

				except:
					continue

Download_xvideos('https://xvideosporno.blog.br/amador/foda-amadora-com-ninfeta-dando-no-mato.html')
